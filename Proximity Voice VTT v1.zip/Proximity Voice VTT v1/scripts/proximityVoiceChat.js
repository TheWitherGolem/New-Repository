// Register the module with Foundry VTT
Hooks.once('init', () => {
    console.log('Initializing Proximity Voice Chat Module...');
});

// Function to calculate distance between tokens
function calculateDistance(token1, token2) {
    const dx = token1.x - token2.x;
    const dy = token1.y - token2.y;
    return Math.sqrt(dx * dx + dy * dy);
}

// Adjust audio volume based on distance
function adjustVolumeForDistance(token) {
    const sceneTokens = canvas.tokens.placeables;
    const userToken = sceneTokens.find(t => t.actor.id === game.user.character.id);
    if (userToken && token.id !== userToken.id) {
        const distance = calculateDistance(userToken, token);
        const maxDistance = 1000; // Maximum distance for hearing, adjust as needed
        const volume = Math.max(0, 1 - (distance / maxDistance));
        // Here you would integrate with the WebRTC library to set the volume
        console.log(`Adjusting volume to ${volume} for token at distance ${distance}`);
    }
}

// Listen for token movement to adjust volume
Hooks.on('updateToken', (scene, token, updateData, options, userId) => {
    if (updateData.x !== undefined || updateData.y !== undefined) {
        adjustVolumeForDistance(token);
    }
});
